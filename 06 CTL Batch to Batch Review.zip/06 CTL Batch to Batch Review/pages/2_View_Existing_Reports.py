# See all batch review reports
import pandas as pd
import streamlit as st
import pandas as pd
import numpy as np
from PIL import Image
import datetime as dt
from datetime import datetime
from fpdf import FPDF
import base64
import os

st.sidebar.title("View Existing Reports")
st.title("View Existing Reports 📌")
st.markdown("You can view or download all submitted reports here")

# Define a function to display a PDF file in the app 
def show_pdf(file_path):
    with open(file_path,"rb") as f:
        base64_pdf = base64.b64encode(f.read()).decode('utf-8')
    pdf_display = f'<iframe src="data:application/pdf;base64,{base64_pdf}" width="800" height="800" type="application/pdf"></iframe>'
    st.markdown(pdf_display, unsafe_allow_html=True)

# get list of files in the reports directory
filelist=[]
for root, dirs, files in os.walk("reports"):
    for file in files:
        filename=os.path.join(root, file)
        filelist.append(filename)

#example filename format BR_25Apr2023_asdasd_8mg_Single.pdf

sort_options = ['Batch Start Date', 'Strength','Process', 'Batch Number']

sort = st.selectbox("Sort By:",
    key="sort_reports",
    options=sort_options
)


def sortfunc():
    if sort == 'Strength':
        new_list = [i.split('_')[3] for i in filelist]
    elif sort == 'Batch Start Date':
        new_list = [datetime.strptime(i.split('_')[1],'%d%b%Y') for i in filelist]
    elif sort == 'Batch Number':
        new_list = [i.split('_')[2] for i in filelist]
    elif sort == 'Process':
        new_list = [i.split('_')[4] for i in filelist]
    else:
        new_list = filelist

    df = pd.DataFrame(list(zip(filelist,new_list)),columns=['filename','sortby'])
    df.sort_values(['sortby'], inplace=True, ascending=False)
    #st.write(new_list)
    filelist2 = df['filename'].values.tolist()
    return filelist2

filelist2 = sortfunc()


i=0
for file in filelist2:
    i=i+1
    filename = file[8:]
    print(filename)
    col1,col2,col3,col4= st.columns([2,1,1,1]) 
    with col1:
        st.write(filename)
    with col2:  
        if st.button('View Report',key='view'+str(i)):            
            show_pdf(file)
    with col3:
        st.button('Close Report',key='close'+str(i))                   
    with col4:
        with open(file, "rb") as pdf_file:
            PDFbyte = pdf_file.read()
            st.download_button(label="Download", key='dl'+str(i), data=PDFbyte, file_name=filename, mime='application/octet-stream')


