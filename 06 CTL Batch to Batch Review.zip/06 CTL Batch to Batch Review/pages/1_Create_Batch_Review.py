

import pandas as pd
import streamlit as st
import pandas as pd
import numpy as np
from PIL import Image
import datetime as dt
from datetime import datetime
from fpdf import FPDF
import base64
from dateutil.relativedelta import relativedelta
#import emoji
from functions.batch_details import batch_details_form
from functions.model_check_form import model_checks_form
from functions.write_pdf import pdf_export
import os

#cwd = os.getcwd()

#print(cwd)

#os.chdir("W:\Ware Data Queries\Data Requests")

#st.write(st.session_state)
# Pages
# Home page showing summary of batch to batch reviews
# Create form page

#st.write(st.session_state)
#initialise batch details submit

#######FORM ##############################
st.sidebar.title("Create Batch Review")
#⭐ 
st.title("Create a New Batch Review 💊")
st.markdown("Please use the below tabs to complete your non-GxP batch review")
st.markdown("***IMPORTANT:** To avoid information loss, please do not move between app pages whilst completing the review*")

tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(["Batch Details","MFG Model","FBD Model","GCU Model","PRESS Model","Save and export"])

with tab1:
    st.subheader("Submit Batch Details")
    batch_details_form()
#create dataframe in which to store batch to batch review data
#batch_details = pd.DataFrame(columns=['batch', 'reviewer','strength','single_dual_sel'])
#all_review_data= pd.read_csv('Review_Data.csv')

with tab2:
    if 'bdsubmit' in st.session_state and st.session_state["bdsubmit"] == True: 
        # workaround to stop error message appearing when pages are changed and widget keys are cleared
        if 'strength' in st.session_state and st.session_state.strength !="Please select":
            model_checks_form(model_type='MFG')
        else:
            st.write("Please submit your batch details before completing the model checks")
    else:
        st.write("Please submit your batch details before completing the model checks")

with tab3:
    if 'bdsubmit' in st.session_state and st.session_state["bdsubmit"] == True: 
        if 'strength' in st.session_state and st.session_state.strength !="Please select":
            model_checks_form(model_type='FBD')
        else:
            st.write("Please submit your batch details before completing the model checks")
    else:
        st.write("Please submit your batch details before completing the model checks")

with tab4:
    if 'bdsubmit' in st.session_state and st.session_state["bdsubmit"] == True: 
        if 'strength' in st.session_state and st.session_state.strength !="Please select":
            model_checks_form(model_type = 'GCU')
        else:
            st.write("Please submit your batch details before completing the model checks")    
    else:
        st.write("Please submit your batch details before completing the model checks")

with tab5:
    if 'bdsubmit' in st.session_state and st.session_state["bdsubmit"] == True: 
        if 'strength' in st.session_state and st.session_state.strength !="Please select":
            model_checks_form(model_type = 'PRESS')
        else:
            st.write("Please submit your batch details before completing the model checks")
    else:
        st.write("Please submit your batch details before completing the model checks")

with tab6:
    # check if all the necessary models are completed
    #st.write(st.session_state)

    pdf_export()
#st.write(st.session_state['Batch'])
#model_checks_form(batch=batch)
    
    #model_checks_submit = st.form_submit_button("Submit")

################## FORM END ##################################
