import streamlit as st

st.set_page_config(
    page_title="Hello",
    page_icon="👋",
)

st.write("# Welcome to the Batch to Batch Review App! 👋")

st.markdown("This application is for creating and tracking non-GxP batch to batch reviews for CTL.")
st.markdown("Please select an action from the sidebar.")

st.sidebar.success("Choose an action above.")