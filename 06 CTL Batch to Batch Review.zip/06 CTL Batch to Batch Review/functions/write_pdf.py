import pandas as pd
import streamlit as st
import pandas as pd
import numpy as np
from PIL import Image
import datetime as dt
from datetime import datetime
from fpdf import FPDF
import base64
from dateutil.relativedelta import relativedelta
#import emoji
import win32com.client as win32
import pythoncom
import os

# EXPORT REPORT 

def pdf_export():
    export_as_pdf = None
    
    # If batch review and all model reviews are submitted, create export button
    #if ['bdsubmit','subMFG','subFBD','subGCU','subPRESS'] in st.session_state and st.session_state['bdsubmit','subMFG','subFBD','subGCU','subPRESS'] == [True,True,True,True,True]:  
        #'subMFG' in st.session_state and st.session_state.subMFG == True and 'subFBD' in st.session_state and st.session_state.subFBD == True :
    #if ['bdsubmit','subMFG','subFBD','subGCU','subPRESS'] in st.session_state and 
    if ('bdsubmit' in st.session_state) & ('subMFG' in st.session_state) & ('subFBD' in st.session_state) & ('subGCU' in st.session_state) & ('subPRESS' in st.session_state):
        if st.session_state.bdsubmit== True & st.session_state.subMFG == True  & st.session_state.subFBD == True & st.session_state.subGCU == True  & st.session_state.subMFG == True:
            export_as_pdf = st.button("Save and Export Report")
    else:
        st.write("Please check all model reviews have been completed")

    # if user clicks export PDF button
    if export_as_pdf:

        # call pdf class and set header and footer 
        class PDF(FPDF):
            def header(self):
                self.set_font('Arial', 'B', 12)
                self.cell(0, 10, 'Batch to Batch Report for Batch ' + st.session_state['batch'], 1, 1, 'C')
                self.ln(10)

            def footer(self):
                self.set_y(-15)
                self.set_font('Arial', 'I', 8)
                self.cell(0, 10, 'Page ' + str(self.page_no()), 0, 0, 'C')


        # 1. Create the PDF file containing all the informtion that has been entered above 

        pdf = PDF()                    # Create PDF object
        pdf.add_page()                  # Add a page
        pdf.set_font('Arial', 'B', 12)  # Set the font
        
        # cell width and height 0
       
        #pdf.ln(10)
        pdf.cell(0, 0, 'Submitted by: ' + st.session_state['reviewer'] + ' on ' + datetime.today().strftime('%Y-%m-%d'))
        pdf.ln(15)    
        pdf.set_font('Arial','',11)
        pdf.cell(0, 0, 'Batch Number: ' + st.session_state['batch'])
        pdf.ln(10)
        pdf.cell(0, 0, 'Start: ' + st.session_state['batch_start_date'] + ' ' + st.session_state['batch_start_time'])
        pdf.ln(10)
        pdf.cell(0, 0, 'End: ' + st.session_state['batch_end_date'] + ' ' + st.session_state['batch_end_time'])
        pdf.ln(10)
        pdf.cell(0, 0, 'Strength: ' + st.session_state['strength'].split(': ')[1])
        pdf.ln(10)
        pdf.cell(0, 0, 'Process: ' + st.session_state['strength'].split(' ')[0])
        pdf.ln(10)

        # work through models and output information for each one    
        for model in ['MFG','FBD','GCU','PRESS']:
            pdf.ln(2)
            pdf.set_font('Arial','B',12)
            #TESTING 
            #if ['upl1'+model] in st.session_state:
            if st.session_state['upl1'+model] is not None:
                pdf.cell(0,0,model+' Model: DModX Chart','C')
                pdf.ln(10)

                img =  Image.open(st.session_state['upl1'+model])
                pdf.image(img,w=170)
                pdf.ln(10)

            # use a loop to output all the files that were saved from the second upload
            #if ['upl2'+model] in st.session_state and 
            if st.session_state['upl2'+model] is not None:
                pdf.ln(10)
                pdf.cell(0,0,model+' Contribution Charts','C')
                pdf.ln(10)
                contrib_count = len(st.session_state['upl2'+model])
               
                for i in st.session_state['upl2'+model]:
                    curr_img=Image.open(i) # get the filename from the list in uploaded_screenshot2
                    #current_image = Image.open(fname)  # open the image so we can use it)
                    pdf.image(curr_img,w=170)
                pdf.ln(10)

            #why_concern what_concern escalation impact
                pdf.cell(0,0,'Description of Concerns')
                pdf.ln(10)
                pdf.set_font('Arial','',11)
                pdf.cell(0, 0, 'What was concerning: ' + st.session_state['what_concern'+model])
                pdf.ln(10)
                pdf.cell(0, 0, 'Why this was concerning: ' + st.session_state['why_concern'+model])
                pdf.ln(10)
                pdf.cell(0, 0, 'Escalation required: ' + st.session_state['escalation'+model])
                pdf.ln(10)
                pdf.cell(0, 0, 'Estimated impact: ' + st.session_state['impact'+model])
                pdf.ln(10)
                
        # 2. Output and save

        # Set the name and directory for the PDF report
        report_title = "BR_" + st.session_state['batch_start_date'] + "_" + st.session_state['batch'] + "_" + st.session_state['strength'].split(': ')[1] + "_" + st.session_state['strength'].split(' ')[0]
    
        report_title_dir = f"reports/{report_title}"

        # Save with the above directory and name
        pdf.output(name = report_title_dir + '.pdf', dest='F')

        # option to preview report and edit inputs before sending email?

        # send email function
        def send_email(subject, body, recipient, attachment):
            outlook = win32.Dispatch('outlook.application')
            mail = outlook.CreateItem(0)
            mail.Subject = subject
            mail.Body = body
            mail.To = recipient
            mail.Attachments.Add(attachment)
            mail.Send()

        subject = 'Non GxP Batch Review Report for batch ' + st.session_state['batch'] 
        body = 'Please see attached batch review report for batch ' + st.session_state['batch']
        recipient = "matthew.w.cannon@gsk.com"
        attachment = os.getcwd() + f'\\reports\\{report_title}.pdf'
        pythoncom.CoInitialize()
        send_email(subject, body, recipient,attachment)


        # notify user that file has been saved
        st.write("Your file has been saved as ", report_title, " and can be viewed using the reports tab. You can also download it using the below link")
        
        def create_download_link(val, filename):
            # encode pdf output file to base 64 
            b64 = base64.b64encode(val)  # val looks like b'...'
            # return link 
            return f'<a href="data:application/octet-stream;base64,{b64.decode()}" download="{filename}.pdf">Download file</a>'

        # Create link to give the option to download the file to your computer
        html_dl_link = create_download_link(pdf.output(dest="S"), report_title)
        
        #display the download link
        st.markdown(html_dl_link, unsafe_allow_html=True)