package_variable = "Hello, I am a package-level variable!"

print("Initializing my_package...")