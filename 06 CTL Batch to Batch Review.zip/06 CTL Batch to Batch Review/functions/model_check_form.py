import pandas as pd
import streamlit as st
import pandas as pd
import numpy as np
from PIL import Image
import datetime as dt
from datetime import datetime
from fpdf import FPDF
import base64
from dateutil.relativedelta import relativedelta
#import emoji


def model_checks_form(model_type):

    if 'sub'+model_type not in st.session_state:
        st.session_state['sub'+model_type]  = False

    # set keys for widgets - add the model type to the end of each one so that they remain unique
    keys = {'upl1':'upl1','confirm':'confirm','upl2':'upl2','what_concern':'what_concern','why_concern':'why_concern','escalation':'escalation','impact':'impact'}
    keys = {x:y+model_type for (x,y) in keys.items()}
         
    with st.form("model_checks"+ model_type,clear_on_submit=False):
        st.subheader("Perform " + model_type + " Model Checks")
        st.markdown("**User Instructions:**")
        st.write("1. Open Simca Online ")
        st.write("2. Login")
        st.write("3. Select 'File - Open - Browse Items'")
        st.write("4. Start " + model_type + " Model")
        st.write("5. Open the configuration'GSK1278863_",model_type,"_",st.session_state['strength'].split(': ')[1],"_",st.session_state['strength'].split(' ')[0],"_v1.0_develop'")
        st.write("6. Open the DModX Chart")
        st.write("7. Right Click and select properties")
        st.write("8. Under time tab, specify time range")
        st.write(f"From: **{st.session_state['batch_start_date']} {st.session_state['batch_start_time']}**")
        st.write(f"To: **{st.session_state['batch_end_date']} {st.session_state['batch_end_time']}**")
        st.write ("NOTE: You may need to press 'apply' and close/re-open to let it set the time you want. This is a known bug.")
        st.write("Take a screenshot of the DModX File, save it and upload below")

        
        keys['upl1'] = st.file_uploader("Upload your saved DModX Screenshot", type=None, accept_multiple_files=False, key=keys['upl1'], help=None, on_change=None, args=None, kwargs=None, disabled=False, label_visibility="visible")
        if keys['upl1'] is not None:
            img_tmp = Image.open(keys['upl1'])
            st.image(img_tmp,caption='DModX')

        keys['confirm'] = st.radio("Looks OK?",
            key=keys['confirm'],
            options=["Select an option","Yes", "No"])

        def validate_form2():
            if keys['upl1'] is None:
                st.error("Please upload the screenshot.")
                return False
            if keys['confirm']=="Select an option":
                st.error("Please confirm the screenshot looks OK.")
                return False
            return True
            
        initial_check_submit = st.form_submit_button("**Save and Continue**")

        if initial_check_submit:
            if validate_form2():
                initial_check = pd.DataFrame([{'Screenshot':keys['upl1'],'All OK?':keys['confirm']}])

            if keys['confirm']=="Yes":
                st.success(f"{model_type} Form submitted successfully, please continue.")
                st.session_state['sub'+model_type]  = True
                #initialise other session state vars in the below form needed for export
                if keys['upl2'] not in st.session_state:
                    st.session_state[keys['upl2']] = None
                if keys['what_concern'] not in st.session_state:
                    st.session_state[keys['what_concern']] = None
                if keys['why_concern'] not in st.session_state:
                    st.session_state[keys['why_concern']] = None
                if keys['escalation'] not in st.session_state:
                    st.session_state[keys['escalation']] = None

    # list of uploaded screenshots looks like this:
    #[0:"UploadedFile(id=3, name='gran_screw_torque_example.png', type='image/png', size=57645)"]

    # set uploaded screenshot2 to blank
    if keys['confirm'] == "No":
        with st.form("further checks"+model_type,clear_on_submit=False):
            st.subheader("**Additional Checks Required**")
            st.markdown("**User Instructions:**")
            st.write("1. Highlight concerning points")
            st.write("2. Right Click")
            st.write("3. Drill Down")
            st.write("4. Take a screenshot of the contribution plot, save and upload below")
            st.write("5. Double click on high contribution parameters")
            st.write("6. Take a screenshot of the key contributions, save and upload all files below")
            keys['upl2'] = st.file_uploader("Upload your saved Contribution Plot Screenshots", type=None, accept_multiple_files=True, key=keys['upl2'], help=None, on_change=None, args=None, kwargs=None, disabled=False, label_visibility="visible")

            if keys['upl2'] is not None:
                count=0 # set the image count to 0
                for i in keys['upl2']:
                    count=count+1 # set the file id
                    #fname=i.name # get the filename from the list in uploaded_screenshot
                    #print(fname)
                    current_image = Image.open(i)  # open the image so we can save it
                    st.image(i) # display the image to the user

            keys['what_concern'] = st.text_input("What was concerning?", key=keys['what_concern'])
            keys['why_concern'] = st.text_input("Why was it concerning?", key=keys["why_concern"])
            keys['escalation'] = st.radio("Escalation Required?",
            key=keys['escalation'],
            options=["Select an option","Yes", "No"])
            keys['impact'] = st.text_input("What is the estimated impact? Consider both this batch and the impact on the next manufactured batch.", key=keys["impact"])

            def validate_form3():
                if keys['upl2'] is None:
                    st.error("Please upload the screenshot(s).")
                    return False
                if not keys['what_concern']:
                    st.error("Please explain what the concern was.")
                    return False
                if not keys['why_concern']:
                    st.error("Please explain why the screenshot(s) are concerning.")
                    return False
                if keys['escalation']=="Select an option":
                    st.error("Please confirm if escalation is required.")
                    return False
                if not keys['impact']:
                    st.error("Please explain the estimated impact.")
                    return False
                return True
            
            model_checks_final = st.form_submit_button(f"**Submit review details for {model_type} model**")

            if model_checks_final:
                if validate_form3():
                    final_check = pd.DataFrame([{'Screenshot':keys['upl2'],'What was concerning?':keys['what_concern'],'Why concerning?':keys['why_concern'],'Escalation Required?':keys['escalation'],"Impact":keys['impact']}])
                    st.session_state['sub'+model_type]  = True
            
    if st.session_state['sub'+model_type]  == True: 
        st.success(f"{model_type} Form submitted successfully, please continue.")




            