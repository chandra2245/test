import pandas as pd
import streamlit as st
import pandas as pd
import numpy as np
from PIL import Image
import datetime as dt
from datetime import datetime
from fpdf import FPDF
import base64
from dateutil.relativedelta import relativedelta
#import emoji


def batch_details_form():
    #initialise submit button session state variable
    if "bdsubmit" not in st.session_state:
        st.session_state.bdsubmit = False 
  
    with st.form("batch_details",clear_on_submit=False):
        #col1,col2,col3,col4 = st.columns(4)
        col1,col2,col3 = st.columns(3)
        with col1:
            reviewer = st.text_input("Reviewer MUD ID",
                key="reviewer",
                max_chars = 9
            )
            batch_start_dt = st.text_input(
                "Batch start date",
                value=datetime.now().date().strftime('%d%b%Y'),
                max_chars=9,
                key = "batch_start_date"
            )

            batch_end_dt = st.text_input(
                "Batch end date",
                value=datetime.now().date().strftime('%d%b%Y'),
                max_chars=9,
                key = "batch_end_date"
            )


        with col2:
            batch = st.text_input("Batch number",
                key="batch"
            )

            default_time=dt.time(hour=0,minute=0)

            batch_start_time = st.text_input(
                "Batch start time",
                value=default_time,
                max_chars=8,
                key = "batch_start_time"
            )
            batch_end_time = st.text_input(
                "Batch end time",
                value=default_time,
                max_chars=8,
                key = "batch_end_time"
            )

        strength_options = ['Please select','Single Feed: 4mg', 'Single Feed: 8mg', 'Dual Feed: 1mg', 'Dual Feed: 2mg', 'Dual Feed: 4mg', 'Dual Feed: 6mg', 'Dual Feed: 8mg']
        with col3:
            strength = st.selectbox("Strength",
                key="strength",
                options=strength_options
            )
            
        '''with col4:
              
            process_sel = st.radio("Process",
                key="process_sel",
                options=["Single", "Dual"]
                #on_change = set_process
            )'''

        def validate_form1():
            if not reviewer:
                st.error("Please enter the reviewer.")
                return False
            if not batch:
                st.error("Please enter the batch number.")
                return False
            if strength == 'Please select':
                st.error("Please enter the strength.")
                return False
            try:
                datetime.strptime(batch_start_dt,'%d%b%Y')
            except ValueError:
                st.error("Please ensure the start date is under the format DDMMMYYYY.")
                return False
            try:
                datetime.strptime(batch_end_dt,'%d%b%Y')
            except ValueError:
                st.error("Please ensure the end date is under the format DDMMMYYYY.")
                return False
            if batch_start_time=="00:00:00":
                st.error("Please enter a start time.")
                return False
            if batch_end_time=="00:00:00":
                st.error("Please enter an end time.")
                return False
            if len(batch_start_time)!=8:
                st.error("Please ensure the start time is under the correct format")
                return False
            if len(batch_end_time)!=8:
                st.error("Please ensure the end time is under the correct format")
                return False

            else: 
                return True 

        #Submit button for initial batch details 
        batch_details_submit = st.form_submit_button("Submit")

        if batch_details_submit:
            if validate_form1():
                # set session state variable for successful submission
                st.session_state.bdsubmit=True

                batch_details = pd.DataFrame([{'reviewer':reviewer,'batch':batch,'strength':strength,'batch_start_dt':batch_start_dt,'batch_end_dt':batch_end_dt}])
                                             #'process_sel':process_sel
            else:
                st.session_state.bdsubmit=False
        
        # make sure that confirm submission statement still exists even when the tab has been changed
        if st.session_state.bdsubmit==True:    
            st.write("Current batch details submitted ", "by ", reviewer, ":", "Batch Number:", batch, "Strength: ", strength, "Batch Start:", batch_start_dt, batch_start_time, "Batch End: ", batch_end_dt, batch_end_time)
            #, "Process: ",process_sel
            st.success("**You can now complete the model reviews in the corresponding tabs.**")
